# Lab Notes

## Lab 1 — Defect Safari

Inspect `data/raw/bayan_raw_sample.csv` and document at least six defect classes.
For each one record: example, why it matters, and clean/preserve/task-dependent.

### Defect 1

- Class:
- Example:
- Why it matters:
- Decision:

### Defect 2

- Class:
- Example:
- Why it matters:
- Decision:

### Defect 3

- Class:
- Example:
- Why it matters:
- Decision:

### Defect 4

- Class:
- Example:
- Why it matters:
- Decision:

### Defect 5

- Class:
- Example:
- Why it matters:
- Decision:

### Defect 6

- Class:
- Example:
- Why it matters:
- Decision:

## Lab 2 — Parameter audit

| Checkpoint | Total params | Embeddings % | Other notes                                             |
| ---------- | -----------: | -----------: | ------------------------------------------------------- |
| mBERT      |  177,853,440 |       51.85% | attention=15.94%, FFN=31.86%, norms=0.02%, pooler=0.33% |
| CAMeLBERT  |  109,081,344 |       21.49% | attention=25.99%, FFN=51.95%, norms=0.03%, pooler=0.54% |

**Why is the embedding share different?**
mBERT covers 104 languages and needs a much larger vocabulary (~120K tokens),
so its embedding table takes over half its total parameters, while
CAMeLBERT is Arabic-only with a much smaller vocabulary — this is the
"multilingual tax." Note that attention, FFN, norms, and pooler parameter
_counts_ are identical between the two models (same BERT-base architecture:
12 layers, 12 heads, d_model=768) — only their embeddings differ.

## Lab 4 — Dialect audit

- Distribution:
- One-sentence implication for MSA-only evaluation:
